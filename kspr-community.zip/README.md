# KSPR AI CLI — distribuidor de licencias

Landing y backend para vender una licencia permanente de KSPR AI CLI mediante Mercado Pago Checkout Pro. El backend solo entrega una clave después de confirmar el pago consultando la API de Mercado Pago y después envía a Formspree una confirmación en texto plano.

## Puesta en marcha

Requisitos: Node.js 18.18 o superior.

```bash
npm install
cp .env.example .env
npm run dev
```

Antes de iniciar ventas:

1. Configura `MP_ACCESS_TOKEN` con el Access Token de tu aplicación de Mercado Pago.
2. Configura `APP_URL` con la URL pública HTTPS de la aplicación.
3. Configura `MP_WEBHOOK_SECRET` con el secreto de Webhooks de Mercado Pago.
4. En Mercado Pago activa el evento de pagos y apunta el webhook a `https://TU_DOMINIO/api/webhooks/mercadopago`.
5. Pega una clave real por línea entre `LICENSE_KEYS_START` y `LICENSE_KEYS_END` en `access-codes.md`, o usa `LICENSE_KEYS`.
6. Ajusta `LICENSE_PRICE` y `LICENSE_CURRENCY` antes de publicar.

En Formspree, activa la acción **Auto Response** si quieres que el comprador reciba también un correo automático. El backend envía siempre un campo `email` y un `message` con la KEY; Formspree usa el primero para identificar al destinatario. La KEY también se muestra una sola vez en `resultado.html` cuando el pago ya está confirmado.

El archivo `data/orders.json` se crea automáticamente y registra las órdenes para evitar reutilizar una KEY. Está excluido de git por contener datos personales y transaccionales.

## Flujo de entrega

La landing captura nombre y correo. El backend crea una preferencia con `external_reference` privado, redirige al comprador a Mercado Pago y recibe el webhook. Para confirmar, consulta `GET /v1/payments/:id` y valida estado `approved`, monto, moneda y referencia interna. Luego asigna una clave, la persiste y publica en Formspree los campos `name`, `email`, `subject` y un `message` de texto plano con la confirmación y la KEY.

La página `resultado.html` no considera suficiente la redirección de Mercado Pago: consulta el estado guardado por el backend y solo muestra la KEY cuando el webhook terminó la entrega.

## Nota de producción

Para una sola instancia, el almacenamiento JSON es suficiente para este proyecto pequeño. Si se despliega en varias instancias o con almacenamiento efímero, cambia `data/orders.json` por una base de datos compartida antes de vender. No subas `.env`, el Access Token ni las claves de licencia al repositorio.

Referencias: [preferencias de Checkout Pro](https://www.mercadopago.com.co/developers/es/reference/online-payments/checkout-pro-preferences/overview), [notificaciones de pago](https://www.mercadopago.com.co/developers/es/docs/checkout-pro-preferences/payment-notifications) y [formularios HTML de Formspree](https://formspree.io/html/).
